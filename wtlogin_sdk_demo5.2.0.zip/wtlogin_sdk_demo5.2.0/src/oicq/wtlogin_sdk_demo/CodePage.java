package oicq.wtlogin_sdk_demo;

import oicq.wlogin_sdk.request.Ticket;
import oicq.wlogin_sdk.request.WUserSigInfo;
import oicq.wlogin_sdk.request.WtloginHelper;
import oicq.wlogin_sdk.request.WtloginListener;
import oicq.wlogin_sdk.request.WtloginHelper.SigType;
import oicq.wlogin_sdk.tools.ErrMsg;
import oicq.wlogin_sdk.tools.util;
import oicq.wtlogin_sdk_demo.R;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class CodePage extends Activity {
	private ImageView code;
	private EditText inputCode;
	private Button btnCode;
	private String account;
	private TextView refresh;
	private TextView promptView;
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); 
        setContentView(R.layout.codepage);
        Login.mLoginHelper.SetListener(mListener);
        
        code = (ImageView)findViewById(R.id.code);
        inputCode = (EditText)findViewById(R.id.inputCode);
        btnCode = (Button)findViewById(R.id.btnCode);
        btnCode.setOnClickListener(onClick);
        refresh = (TextView)findViewById(R.id.refresh);
        refresh.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
        refresh.setOnClickListener(onClick);
        refresh.setOnTouchListener(onTouchListener);
        promptView = (TextView)findViewById(R.id.image_prompt);
        
        Bundle bundle = new Bundle();
        bundle = getIntent().getExtras();
        account = bundle.getString("ACCOUNT");
        String prompt_value = bundle.getString("PROMPT");
        if (prompt_value != null && prompt_value.length() > 0) {
        	promptView.setText(prompt_value);
        }
        byte[] tmp = bundle.getByteArray("CODE");
		Bitmap bm = BitmapFactory.decodeByteArray(tmp, 0, tmp.length);
		code.setImageBitmap(bm);
	}
	
	private View.OnTouchListener onTouchListener = new View.OnTouchListener() {
		public boolean onTouch(View v, MotionEvent event) {
			int id = v.getId();
	        switch(event.getAction())
	        {
	        	case MotionEvent.ACTION_DOWN:
	        		{
	        			if(id == R.id.refresh)
	        				refresh.setTextColor(CodePage.this.getResources().getColor(R.color.textFocus));
	        		}
	        		break;
	        	case MotionEvent.ACTION_UP:
	        		{
	        			if(id == R.id.refresh)
	        				refresh.setTextColor(CodePage.this.getResources().getColor(R.color.white));
	        		}
	        		break;
	        	case MotionEvent.ACTION_MOVE:
	        		break;
	        }
			return false;
		}
	};
	
	private View.OnClickListener onClick = new View.OnClickListener()
	{
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.btnCode:
				{
					WUserSigInfo sigInfo = new WUserSigInfo();
					Login.mLoginHelper.CheckPictureAndGetSt(account,inputCode.getText().toString().getBytes(),	sigInfo);
				}
				break;
			case R.id.refresh:
				{
					WUserSigInfo sigInfo = new WUserSigInfo();
					Login.mLoginHelper.RefreshPictureData(account, sigInfo);
				}
			break;
			default:
				break;
			}
		}
	};
	
	WtloginListener mListener = new WtloginListener()
	{
		public void OnCheckPictureAndGetSt(String userAccount,byte[] userInput, WUserSigInfo userSigInfo, int ret, ErrMsg errMsg)
		{
	      	if(ret == util.S_GET_IMAGE){
	      		byte[] image_buf = new byte[0];
	      		image_buf = Login.mLoginHelper.GetPictureData(userAccount);
	      		if(image_buf == null){
	      			return;
	      		}
	      	    //获取验证码提示语
	      		String prompt_value = Login.getImagePrompt(userAccount, Login.mLoginHelper.GetPicturePrompt(userAccount));
				if (prompt_value != null && prompt_value.length() > 0) {
					promptView.setText(prompt_value);
				}
	      		Bitmap bm = BitmapFactory.decodeByteArray(image_buf, 0, image_buf.length);
				code.setImageBitmap(bm);
				Login.showDialog(CodePage.this, "验证码有误，请尝试重新输入。");
				inputCode.setText("");
	      	}
	      	else
	      	{
	      		util.LOGI("time_difference:" + Login.mLoginHelper.GetTimeDifference());
	      		if (ret != util.S_SUCCESS) {
	      			util.LOGI("err msg:" + " title:" + errMsg.getTitle() + " msg:" + errMsg.getMessage());
	      		}
	      		
	      		Ticket ticket = WtloginHelper.GetUserSigInfoTicket(userSigInfo, SigType.WLOGIN_D2);
				util.LOGI("d2: " + util.buf_to_string(ticket._sig) + " d2key: " + util.buf_to_string(ticket._sig_key));
				
	      		Intent intent = new Intent();
	      		Bundle bundle = new Bundle();
  				bundle.putString("ACCOUNT", userAccount);
  				bundle.putParcelable("ERRMSG", errMsg);
  				bundle.putParcelable("USERSIG", userSigInfo);
  				intent.putExtras(bundle);
	      		//CodePage.this.setIntent(intent);
				CodePage.this.setResult(ret,intent);
				CodePage.this.finish();
      			return;
	        } 
		}
		
		public void OnRefreshPictureData(String userAccount, WUserSigInfo userSigInfo, byte[] pictureData, int ret, ErrMsg errMsg)
		{
	      	if(ret == util.S_SUCCESS){
	      		byte[] image_buf = new byte[0];
	      		image_buf = Login.mLoginHelper.GetPictureData(userAccount);
	      		if(image_buf == null)
	      		{
	      			return;
	      		}
	      	    //获取验证码提示语
	      		String prompt_value = Login.getImagePrompt(userAccount, Login.mLoginHelper.GetPicturePrompt(userAccount));
				if (prompt_value != null && prompt_value.length() > 0) {
					promptView.setText(prompt_value);
				}
	      		Bitmap bm = BitmapFactory.decodeByteArray(image_buf, 0, image_buf.length);
				code.setImageBitmap(bm);
	      	}  			
		}
	};
}
