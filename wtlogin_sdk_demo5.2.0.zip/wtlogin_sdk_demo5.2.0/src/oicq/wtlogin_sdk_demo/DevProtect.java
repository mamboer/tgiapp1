package oicq.wtlogin_sdk_demo;

import oicq.wlogin_sdk.devicelock.DevlockInfo;
import oicq.wlogin_sdk.request.WUserSigInfo;
import oicq.wlogin_sdk.request.WtloginListener;
import oicq.wlogin_sdk.tools.ErrMsg;
import oicq.wlogin_sdk.tools.util;
import oicq.wtlogin_sdk_demo.R;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

public class DevProtect extends Activity {
	private DevlockInfo mDevlockInfo;
	private static String mAccount;
	private Button btnVerify;
	private TextView mbMobile;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.devprotect);
		
		Login.mLoginHelper.SetListener(mListener);
		
		mbMobile = (TextView)findViewById(R.id.mbMobile);
		btnVerify = (Button)findViewById(R.id.startVerify);
		btnVerify.setOnClickListener(onClick);
		
		Bundle bundle = new Bundle();
		bundle = getIntent().getExtras();
		mAccount = bundle.getString("ACCOUNT");
		mDevlockInfo = bundle.getParcelable("DEVLOCKINFO");
		if (mDevlockInfo != null) {
			mbMobile.setText(mDevlockInfo.Mobile);
		}
	}
	
	private View.OnClickListener onClick = new View.OnClickListener()
	{
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.startVerify:
				{
					WUserSigInfo sigInfo = new WUserSigInfo();
					Login.mLoginHelper.RefreshSMSData(mAccount, Login.mSmsAppid, sigInfo);
				}
				break;
				
			default:
				break;
			}
		}
	};
	
	WtloginListener mListener = new WtloginListener()
	{
		public void OnRefreshSMSData(String userAccount, long smsAppid, WUserSigInfo userSigInfo, int remainMsgCnt, int timeLimit, int ret, ErrMsg errMsg)
		{
			if (ret == util.S_SUCCESS) {
				util.LOGI("remainMsgCnt:" + remainMsgCnt + " timeLimit:" + timeLimit);
				Intent intent = new Intent();
	      		intent.setClass(DevProtect.this, DevVerify.class);
	      		Bundle bundle = new Bundle();
	      		bundle.putString("ACCOUNT", userAccount);
  				bundle.putParcelable("DEVLOCKINFO", mDevlockInfo);
  				bundle.putLong("REMAINMSGCNT", remainMsgCnt);
  				bundle.putLong("TIMELIMIT", timeLimit);
  				intent.putExtras(bundle);
  				startActivity(intent);
  				DevProtect.this.finish();
  				//DevProtect.this.startActivityForResult(intent, 2);
			} else {
				Login.showDialog(DevProtect.this, errMsg);
			}
		}
	};
	
}
