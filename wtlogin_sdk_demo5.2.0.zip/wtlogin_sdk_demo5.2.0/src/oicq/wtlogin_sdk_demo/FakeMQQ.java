package oicq.wtlogin_sdk_demo;

import oicq.wlogin_sdk.request.Ticket;
import oicq.wlogin_sdk.request.WUserSigInfo;
import oicq.wlogin_sdk.request.WtloginHelper;
import oicq.wlogin_sdk.request.WtloginListener;
import oicq.wlogin_sdk.request.WtloginHelper.SigType;
import oicq.wlogin_sdk.sharemem.WloginSimpleInfo;
import oicq.wlogin_sdk.tools.ErrMsg;
import oicq.wlogin_sdk.tools.RSACrypt;
import oicq.wlogin_sdk.tools.util;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.widget.TextView;

public class FakeMQQ extends Activity {

	private WtloginHelper mLoginHelper = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_fake_mqq);
		
		if (Login.mLoginHelper == null)
			Login.mLoginHelper = new LoginHelper(getApplicationContext());
		this.mLoginHelper = Login.mLoginHelper;
		mLoginHelper.SetListener(mListener);
		
		login();
	}
	
	private void onlyDecrypt() {
		Intent intent = getIntent();
		byte[] cipher = intent.getByteArrayExtra("data");
		RSACrypt rsa = new RSACrypt(this);
		
		byte[] plain = rsa.DecryptData(null, cipher);
		util.LOGI("从微信来的数据： " + new String(plain));
		
		TextView textView = (TextView) findViewById(R.id.fakemqq_info);
		textView.setText(new String(plain));
	}
	
	private void login() {
		Intent data = getIntent();
		try {
			WUserSigInfo sigInfo = mLoginHelper.ResolveQloginIntent(data);
			if (sigInfo == null) {
				Login.showDialog(this, "快速登录失败");
				return;
			}
			
			String uin = sigInfo.uin;
			TextView textView = (TextView) findViewById(R.id.fakemqq_info);
			textView.setText("用户("+uin+")快速登录中。。。, fast login buffer: " + util.buf_to_string(sigInfo._fastLoginBuf));
			
			mLoginHelper.GetStWithPasswd(uin, Login.mAppid, 0x1, Login.mMainSigMap, "", sigInfo);
			this.finish();
			loginSuccess("" + uin);
		} catch (Exception e) {
			util.printException(e);
		}
	}
	
	private void loginSuccess(String userAccount) {
		WloginSimpleInfo info = new WloginSimpleInfo();
		mLoginHelper.GetBasicUserInfo(userAccount, info);

		Intent intent = new Intent();
		intent.setClass(FakeMQQ.this, LoginOk.class);
		intent.putExtra("RET", 0);
		intent.putExtra("ACCOUNT", userAccount);
		intent.putExtra("UIN", new Long(info._uin).toString());
		intent.putExtra("NICK", new String(info._nick));
		intent.putExtra("FACE", new String(info._img_url));
		int gender = info._gender[0];
		if (gender == 0) {
			intent.putExtra("GENDER", "女");
		} else if (gender == 1) {
			intent.putExtra("GENDER", "男");
		} else {
			intent.putExtra("GENDER", "未知");
		}

		Integer age = (int) info._age[0];
		intent.putExtra("AGE", age.toString());
		startActivity(intent);
	}
	
	WtloginListener mListener = new WtloginListener() {
		public void OnGetStWithPasswd(String userAccount, long dwSrcAppid,
				int dwMainSigMap, long dwSubDstAppid, String userPasswd,
				WUserSigInfo userSigInfo, int ret, ErrMsg errMsg) {
			if (ret == util.S_SUCCESS) {
				// 示例：获取st票据
				Ticket ticket = mLoginHelper.GetLocalTicket(userAccount, dwSrcAppid, SigType.WLOGIN_ST);
				util.LOGI("st:" + util.buf_to_string(ticket._sig) + " st_key:"
						+ util.buf_to_string(ticket._sig_key) + " create_time:"
						+ ticket._create_time + " expire_time:"
						+ ticket._expire_time);
				loginSuccess(userAccount);
			} else if (ret == 0xF) {
				// 可能A2过期，或者用户修改密码导致A2失效
				Login.showDialog(FakeMQQ.this, "A2失效，请尝试用A1登录或直接用密码登录");
			} else {
				Login.showDialog(FakeMQQ.this, errMsg);
			}
		}
	};
}
