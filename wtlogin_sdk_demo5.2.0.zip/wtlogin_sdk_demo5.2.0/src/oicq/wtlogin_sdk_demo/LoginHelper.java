package oicq.wtlogin_sdk_demo;

import oicq.wlogin_sdk.request.WtloginHelper;
import android.content.Context;


public class LoginHelper extends WtloginHelper { 
	
	public LoginHelper(Context context){
		super(context);
	}
} 