package oicq.wtlogin_sdk_demo.register;

import oicq.wlogin_sdk.request.WUserSigInfo;
import oicq.wlogin_sdk.request.WtloginListener;
import oicq.wlogin_sdk.tools.util;
import oicq.wtlogin_sdk_demo.Login;
import oicq.wtlogin_sdk_demo.R;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

public class InputMobile extends Activity {

	int mRegType = 0;
	int mFlowId = 0;
	Button mNextStepButton;
	EditText mMobile;
	CheckBox agree;
	TextView serverItem;
	TextView step;
	TextView title;
	
	private PopupWindow popup;
	private Button goon;
	private Button toLogin;
	private Button change;
	private int mRet = 0;
	private LinearLayout server;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE); 
		setContentView(R.layout.inputmobile);
		
		Intent intent = getIntent();
		mRegType = intent.getIntExtra("TYPE", 0);
		util.LOGD("InputMobile::onCreate:" + mRegType);

		Login.mLoginHelper.SetListener(mListener);
		step = (TextView)findViewById(R.id.step1);
		step.setTextColor(Color.WHITE);
		ImageView step3 = (ImageView)findViewById(R.id.step);
		step3.getBackground().setAlpha(150);

		title = (TextView)findViewById(R.id.title);
		if(mRegType == 0)
			title.setText(getResources().getString(R.string.regQQ));
		else if(mRegType == 1)
			title.setText(getResources().getString(R.string.regPhone));
		else if(mRegType == 3)
		{
			title.setText(getResources().getString(R.string.regEmail));
			server = (LinearLayout)findViewById(R.id.serverterm);
			server.setVisibility(View.GONE);
		}
		
		agree = (CheckBox)findViewById(R.id.checkOK);
		serverItem = (TextView)findViewById(R.id.agree);
		serverItem.setOnClickListener(onClick);
		serverItem.setOnTouchListener(onTouchListener);
		
		mMobile = (EditText) findViewById(R.id.editText1);
		mNextStepButton = (Button) findViewById(R.id.btn_next);
		mNextStepButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				if(!agree.isChecked())
				{
					Login.showDialog(InputMobile.this, "您尚未同意《腾讯服务条款》。");
					return;
				}
				String mobile = mMobile.getText().toString().trim();
				//if("".equals(mMobile.getText().toString().trim()))
				if(mobile.length() == 0)
				{
					Login.showDialog(InputMobile.this, "请输入手机号码。");
					return;
				}
				else if(mobile.length() < 11)
				{
					Login.showDialog(InputMobile.this, "您输入的号码有误，请检查后重新输入。");
					return;
				}
				if (mRegType == Login.TYPE_REQ_EMAIL) {
					Login.mLoginHelper.RegSubmitMobile(mMobile
							.getText().toString().getBytes(),
							Login.mAppName.getBytes(),
							Login.mAppVersion.getBytes(), 0, 2, 0,
							Login.mAppid, null);
				} 
				else if(mRegType == Login.TYPE_REQ_QQ){
					Login.mLoginHelper.RegQueryAccount(mRegType,
							new byte[0],
							Login.mAppid, null);
				}
				else {
					Login.mLoginHelper.RegQueryAccount(mRegType,
							mMobile.getText().toString().getBytes(),
							Login.mAppid, null);
				}
			}
		});
	}
	
	private View.OnTouchListener onTouchListener = new View.OnTouchListener() {
		public boolean onTouch(View v, MotionEvent event) {
			int id = v.getId();
	        switch(event.getAction())
	        {
	        	case MotionEvent.ACTION_DOWN:
	        		{
	        			if(id == R.id.agree)
	        				serverItem.setTextColor(InputMobile.this.getResources().getColor(R.color.textFocus));
	        		}
	        		break;
	        	case MotionEvent.ACTION_UP:
	        		{
	        			if(id == R.id.agree)
	        				serverItem.setTextColor(InputMobile.this.getResources().getColor(R.color.white));
	        		}
	        		break;
	        	case MotionEvent.ACTION_MOVE:
	        		break;
	        }
			return false;
		}
	};
	
	private View.OnClickListener onClick = new View.OnClickListener()
	{
		public void onClick(View v) {
			// TODO Auto-generated method stub
			switch(v.getId())
			{
				case R.id.agree:
					{
						Intent intent = new Intent("android.intent.action.VIEW",Uri.parse(getString(R.string.agreeItem)));
						startActivity(intent);
					}
					break;
				case R.id.goon:
					{
						//解绑并且继续注册
						popup.dismiss();
						mListener.OnRegQueryAccount(null, mRet, new byte[0]);
					}
				break;
				case R.id.tologin:
					{
						popup.dismiss();
						Login.gLoginNow  = true;
						Login.gAccount = mMobile.getText().toString().trim();
						Login.gPasswd = "";
						InputMobile.this.finish();
					}
					break;
				case R.id.change:
					{
						popup.dismiss();
						mMobile.setText("");
					}
					break;
				default:
					break;
			}
		}
	};
	
	@SuppressLint("NewApi")
	private void initPopuWindows() {
		//初始化PopupWindow,LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT控制显示
		LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View contentView = layoutInflater.inflate(R.layout.phoneexist, null);
		DisplayMetrics metric = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metric);
        int densityDpi = metric.densityDpi;
		//popup = new PopupWindow(findViewById(R.id.inputMobile), 300*densityDpi/160,ViewGroup.LayoutParams.FILL_PARENT);
        popup = new PopupWindow(findViewById(R.id.inputMobile), ViewGroup.LayoutParams.FILL_PARENT,ViewGroup.LayoutParams.FILL_PARENT);
		popup.setContentView(contentView);
		popup.setFocusable(true);
		
		popup.setBackgroundDrawable(new BitmapDrawable());
		popup.isTouchable();
		popup.setAnimationStyle(R.style.AnimationFade);
		popup.showAtLocation(this.findViewById(R.id.inputMobile), Gravity.CENTER, 0 , 0);//这个一定要放在setBackgroundDrawable后面
		
		goon = (Button) contentView.findViewById(R.id.goon);
		goon.setOnClickListener(onClick);
		toLogin = (Button) contentView.findViewById(R.id.tologin);
		toLogin.setOnClickListener(onClick);
		change = (Button) contentView.findViewById(R.id.change);
		change.setOnClickListener(onClick);
	}

	public void OnError() {
		AlertDialog.Builder builder = new Builder(InputMobile.this);
		builder.setMessage("出错啦!");
		builder.setTitle("QQ通行证");
		builder.setPositiveButton("确认", new OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				/*Intent intent = new Intent();
				intent.setClass(InputMobile.this, UserInfo.class);
				startActivity(intent);*/
				//InputMobile.this.finish();
				mMobile.setText("");
			}
		});
		builder.create().show();
	}

	WtloginListener mListener = new WtloginListener() {
		public void OnRegError(WUserSigInfo userSigInfo, int ret, byte[] msg) {
			util.LOGD("OnRegError:" + ret);
			OnError();
		}

		// 下行短信
		@Override
		public void OnRegCheckDownloadMsg(WUserSigInfo userSigInfo, int ret, byte[] msg) {
			util.LOGD("OnRegCheckDownloadMsg:" + ret);
			Intent intent = new Intent();
			intent.setClass(InputMobile.this, InputMsgChk.class);
			intent.putExtra("TYPE", mRegType);
			if(mRegType == 1)
				Login.gAccount = mMobile.getText().toString().trim();
			intent.putExtra("RET", ret);
			intent.putExtra("MSG", new String(msg));
			startActivity(intent);
			InputMobile.this.finish();
		}

		// 上行短信
		@Override
		public void OnRegCheckUploadMsg(WUserSigInfo userSigInfo, byte[] mobile, byte[] msg) {
			util.LOGD("OnRegCheckUploadMsg:" + new String(msg));
			Intent intent = new Intent();
			intent.setClass(InputMobile.this, SendMsg.class);
			intent.putExtra("TYPE", mRegType);
			if(mRegType == 1)
				Login.gAccount = mMobile.getText().toString().trim();
			intent.putExtra("MOBILE", new String(mobile));
			intent.putExtra("MSG", new String(msg));
			startActivity(intent);
			InputMobile.this.finish();
		}

		// url跳转
		public void OnRegCheckValidUrl(WUserSigInfo userSigInfo, byte[] url) {
			util.LOGD("OnRegCheckValidUrl:" + new String(url));
			Intent urlIntent = new Intent("android.intent.action.VIEW", Uri.parse("http://" + new String(url)));//http://zc.qq.com/chs/index.html
			startActivity(urlIntent);
			InputMobile.this.finish();
		}

		/*
		 * 
		 * //CResultCode ： 0 辅助账号不存在，后续注册需要验证手机号， 1 辅助账号已存在，后续注册需要验证手机 2
		 * 辅助账号不存在，后续注册不需要验证手机号 3辅助账号存在，后续注册不验证手机
		 */
		public void OnRegQueryAccount(WUserSigInfo userSigInfo, int ret, byte[] msg) {
			util.LOGI("OnRegQueryAccount:" + ret);
			if(ret == 1 || ret == 3)
			{
				initPopuWindows();
				mRet = ret -1;
				return;
			}
			mFlowId = ret;
			switch (mFlowId) {
			case 0:
			case 1:
				Login.mLoginHelper.RegSubmitMobile(mMobile.getText()
						.toString().getBytes(),
						Login.mAppName.getBytes(),
						Login.mAppVersion.getBytes(), 0, 2, 0,
						Login.mAppid, userSigInfo);
				break;
			case 2:
			case 3: {
				if(mRegType == 1)
					Login.gAccount = mMobile.getText().toString().trim();
				Intent intent = new Intent();
				intent.setClass(InputMobile.this, InputPasswd.class);
				intent.putExtra("TYPE", mRegType);
				intent.putExtra("MSG", new String(msg));
				startActivity(intent);
				InputMobile.this.finish();
			}
				break;
			default:
				OnError();
				break;
			}
		}

	};

}
