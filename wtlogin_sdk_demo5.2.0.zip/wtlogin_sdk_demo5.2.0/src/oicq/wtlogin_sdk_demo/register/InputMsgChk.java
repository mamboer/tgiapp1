package oicq.wtlogin_sdk_demo.register;
import java.util.TimerTask;

import oicq.wlogin_sdk.request.WUserSigInfo;
import oicq.wlogin_sdk.request.WtloginListener;
import oicq.wlogin_sdk.tools.util;
import oicq.wtlogin_sdk_demo.Login;
import oicq.wtlogin_sdk_demo.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

//下行短信流程
public class InputMsgChk  extends Activity {
	
	int mRegType = 0;
	String mMsg = "";
	int mDelay = 10;

	EditText mMsgEditText;
	Button mReSendButton;
	Button mNextStepButton;
	private CountMsgChk refresh;
	private String mAccount;
	private int refreshNum = 0;
	TextView step;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); 
        setContentView(R.layout.inoutmsgchk);  
        
        Intent intent = this.getIntent();
        mRegType = intent.getIntExtra("TYPE", 0);
        mMsg = intent.getStringExtra("MSG");
        mAccount = intent.getStringExtra("ACCOUNT");
        Log.w("AAAA", "msg:::"+mMsg);
        
        Login.mLoginHelper.SetListener(mListener);
        
        TextView title = (TextView)findViewById(R.id.title);
		if(mRegType == 0)
			title.setText(getResources().getString(R.string.regQQ));
		else if(mRegType == 1)
			title.setText(getResources().getString(R.string.regPhone));
		else if(mRegType == 3)
			title.setText(getResources().getString(R.string.regEmail));
        mMsgEditText = (EditText) findViewById(R.id.editText1);
        step = (TextView)findViewById(R.id.step1);
		step.setTextColor(Color.WHITE);
        //mMsgEditText.setText(mMsg);
        
        mReSendButton = (Button) findViewById(R.id.btn_refresh); 
        mReSendButton.setEnabled(false);
        mReSendButton.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {	
        		//refresh = new CountMsgChk(10000, 1000);
                //refresh.start();
        		mReSendButton.setEnabled(false);
        		if(refreshNum < 30)
        			refreshNum++;
        		else
        		{
        			Login.showDialog(InputMsgChk.this, "您刷新太多次数了。");
        			return;
        		}
        		Login.mLoginHelper.RegRequestServerResendMsg(new WUserSigInfo());
        		//tools.showDialog(InputMsgChk.this, "......");
        	} 
        });          
        
        mNextStepButton = (Button) findViewById(R.id.btn_next); 
        mNextStepButton.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {	
        		mMsg = mMsgEditText.getText().toString();
        		Login.mLoginHelper.RegSubmitMsgChk(mMsg.getBytes(), new WUserSigInfo());
        	} 
        }); 
        refresh = new CountMsgChk(30000, 1000);
        refresh.start(); 
        mReSendButton.getBackground().setAlpha(127);
    }
    
    class CountMsgChk extends CountDownTimer {     
        public CountMsgChk(long millisInFuture, long countDownInterval) {     
            super(millisInFuture, countDownInterval);     
        }     
        @Override     
        public void onFinish() {    
        	mReSendButton.setText("重新获取"); 
        	mReSendButton.setEnabled(true);
        	mReSendButton.getBackground().setAlpha(255);
        }     
        @Override     
        public void onTick(long millisUntilFinished) {     
        	mReSendButton.setText("重新获取(" + millisUntilFinished / 1000 + "s后)");     
        }    
    }  
    
	public void OnError()
	{
		AlertDialog.Builder builder = new Builder(InputMsgChk.this);
		builder.setMessage("验证码有误，请检查后重新输入。");
		builder.setTitle("QQ通行证");
		builder.setPositiveButton("确认", new OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				/*Intent intent = new Intent();
				intent.setClass(InputMsgChk.this, UserInfo.class);
				startActivity(intent);
				InputMsgChk.this.finish();*/
				mMsgEditText.setText("");
			}
		});
		builder.create().show();		
	}    
    
    WtloginListener mListener = new WtloginListener(){
    	@Override
    	public void OnRegError(WUserSigInfo userSigInfo, int ret, byte[] msg)
    	{
    		util.LOGD("OnRegError:"+ret);
    		OnError();
    	}
    	
    	//提交验证码回调
    	@Override
    	public void OnRegSubmitMsgChk(WUserSigInfo userSigInfo, int ret, byte[] msg)
    	{
    		util.LOGI("OnRegSubmitMsgChk:");
    		if(ret == 0)
    		{
    			Intent intent = new Intent();
	       	     intent.setClass(InputMsgChk.this, InputPasswd.class);
	    	     intent.putExtra("TYPE", mRegType);
	    	     intent.putExtra("MSG", mMsg);
	    	     intent.putExtra("ACCOUNT", mAccount);
	    	     startActivity(intent);   
	    	     InputMsgChk.this.finish();
    		}
    		else
    		{
    			util.LOGI("OnRegSubmitMsgChk error:"+ret);
    			OnError();
    		}
    	}
    	
    	//重发下行短信回调
    	@Override
    	public void OnRegRequestServerResendMsg(WUserSigInfo userSigInfo, int ret, int next_chk_time, int total_time_over)
    	{
    		//util.LOGD("OnRegQueryClientSendedMsgStatus:"+ret);
    		refresh = new CountMsgChk(next_chk_time * 1000, 1000);
            refresh.start(); 
    		 
    	}	
    	
    	//url跳转
    	@Override
    	public void OnRegCheckValidUrl(WUserSigInfo userSigInfo, byte[] url)
    	{
    		util.LOGI("OnRegCheckValidUrl:" + url);
			Intent urlIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(new String(url)));
			startActivity(urlIntent);   
			InputMsgChk.this.finish();
    	}		    	
    	
    };    
       
}
