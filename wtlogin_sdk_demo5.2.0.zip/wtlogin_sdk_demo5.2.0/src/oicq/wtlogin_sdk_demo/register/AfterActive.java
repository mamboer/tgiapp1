package oicq.wtlogin_sdk_demo.register;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import oicq.wlogin_sdk.tools.util;
import oicq.wtlogin_sdk_demo.Login;
import oicq.wtlogin_sdk_demo.R;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;


@SuppressLint("NewApi")
public class AfterActive extends Activity {
	private TextView step;
	private Button toLogin;
	private String mUin;
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); 
        setContentView(R.layout.afteractive); 
        
        try{
        
        step = (TextView)findViewById(R.id.step3);
        step.setTextColor(Color.WHITE);
        step = (TextView)findViewById(R.id.step1);
		step.setText("①邮箱验证");
        
        toLogin = (Button)findViewById(R.id.btn_login);
        toLogin.setOnClickListener(onClick);
        
        Uri data = getIntent().getData();
		if(data == null)
		{
			return;
		}
		
		TextView account = (TextView)findViewById(R.id.bduin);
		//mUin = strData.substring(strData.indexOf("uin="+4), strData.indexOf("&"));
		mUin = data.getQueryParameter("uin");
		account.setText(mUin);
		TextView eMail = (TextView)findViewById(R.id.emailAccount);
		eMail.setText(Login.gAccount);
        }
        catch(Exception e)
        {
        	Log.e("AAAA", e.toString());
        	StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw, true);
            e.printStackTrace(pw);
            pw.flush();
            sw.flush();
            String s = sw.toString(); 
            util.LOGW("exception", s);
        }
	}
	
	protected void onResume() {
		super.onResume();
	}
	
	private View.OnClickListener onClick = new View.OnClickListener()
	{
		public void onClick(View arg0) {
			switch(arg0.getId())
			{
				case R.id.btn_login://激活完成以后跳到登录页还是注册完成页保存QQ号？
					{
						Login.gLoginNow = true;
						Intent intent = new Intent();
						Bundle bundle = new Bundle();
			      		intent.putExtras(bundle);
						intent.setClass(AfterActive.this, Login.class);
						startActivity(intent);
						AfterActive.this.finish();
					}
					break;
				default:
					break;
			}
		}	
	};
	
	public void onWindowFocusChanged(boolean hasFocus) {
        // TODO Auto-generated method stub
        super.onWindowFocusChanged(hasFocus);
        saveUin();
    }

	public void saveUin()
	{
		View view = AfterActive.this.getWindow().getDecorView();
	    view.setDrawingCacheEnabled(true);
	    view.buildDrawingCache();
	    Bitmap b1 = view.getDrawingCache();

	    Rect frame = new Rect();
	    DisplayMetrics metric = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metric);

	    // 获取屏幕长和高
	    int width = metric.widthPixels;
	    int height = metric.heightPixels;
	    
	    
        getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
        int statusBarHeight = frame.top;

	    Bitmap bmp = Bitmap.createBitmap(b1, 0, statusBarHeight, width, height- statusBarHeight);
	    view.destroyDrawingCache();
	    
	    String path = Environment.getExternalStorageDirectory() + "/QQPassPort/";
	    File file = new File(path);
	    if(!file.exists())
	    	file.mkdir();
	    
	    File myPic = new File(path + mUin + ".jpg");

         FileOutputStream f = null;
         try {
        	 f = new FileOutputStream(myPic);
        	 boolean b = bmp.compress(Bitmap.CompressFormat.JPEG, 100, f);
             if(b){
            	 f.flush();
             }
             f.close();
         } catch (FileNotFoundException e) {
        	 e.printStackTrace();
         }
         catch (IOException e) {
             e.printStackTrace();
         }
         
         sendBroadcast(new Intent(Intent.ACTION_MEDIA_MOUNTED, Uri.parse("file://"  
                 + Environment.getExternalStorageDirectory() + "/QQPassPort")));
     
	}
}