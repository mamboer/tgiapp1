package oicq.wtlogin_sdk_demo.register;

import oicq.wtlogin_sdk_demo.Login;
import oicq.wtlogin_sdk_demo.R;
import oicq.wlogin_sdk.request.WUserSigInfo;
import oicq.wlogin_sdk.request.WtloginListener;
import oicq.wlogin_sdk.tools.util;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

//上行短信流程
public class SendMsg extends Activity {
	int mRegType = 0;
	String mMobile = "";
	String mMsg = "";

	TextView mMsgEditText;
	Button mNextStepButton;
	Button mQueryButton;
	private TextView step;
	private TextView code;
	private TextView number;
	private CountMsgChk refresh;
	private boolean sendMsg  = false;
	private int overTime = 0;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE); 
		setContentView(R.layout.sendmsg);

		Intent intent = this.getIntent();
		mRegType = intent.getIntExtra("TYPE", 0);
		mMobile = intent.getStringExtra("MOBILE");
		mMsg = intent.getStringExtra("MSG");

		Login.mLoginHelper.SetListener(mListener);
		
		TextView title = (TextView)findViewById(R.id.title);
		if(mRegType == 0)
			title.setText(getResources().getString(R.string.regQQ));
		else if(mRegType == 1)
			title.setText(getResources().getString(R.string.regPhone));
		else if(mRegType == 3)
			title.setText(getResources().getString(R.string.regEmail));

		//mMsgEditText = (TextView) findViewById(R.id.textView1);
		//mMsgEditText.setText("请发短信【"+mMsg+"】至:"+mMobile);
		step = (TextView)findViewById(R.id.step1);
		step.setTextColor(Color.WHITE);
		
		code = (TextView)findViewById(R.id.code);
		code.setText(mMsg);
		number = (TextView)findViewById(R.id.number);
		number.setText(mMobile);
		
		mNextStepButton = (Button) findViewById(R.id.btn_sendmsg);
		mNextStepButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				// 发短信
				Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("sms:"+mMobile));
				intent.putExtra("address", mMobile);
				intent.putExtra("sms_body", mMsg);
				startActivity(intent);
				sendMsg = true;
			}
		});
		
		
	}
	
	protected void onResume() {
		super.onResume();
		//发送短信以后回到该页面，去轮询服务器有没有收到用户发送的短信
		//UserInfo.mLoginHelper.RegQueryClientSendedMsgStatus();
		Login.mLoginHelper.SetListener(mListener);
		if(sendMsg)
		{
			Log.e("AAAA", "begin to query the server");
			overTime = 0;
			refresh = new CountMsgChk(7000, 7000);
			refresh.start();
			sendMsg = false;
		}
		
	}
	
	class CountMsgChk extends CountDownTimer { 
		private long future;
        public CountMsgChk(long millisInFuture, long countDownInterval) {     
            super(millisInFuture, countDownInterval);  
            future  = millisInFuture/1000;
        }     
        @Override     
        public void onFinish() {    
        	//SendMsg.this.finish();
        	overTime += future;
        	Login.mLoginHelper.RegQueryClientSendedMsgStatus(new WUserSigInfo()); 
        }     
        @Override     
        public void onTick(long millisUntilFinished) {     
        	Log.e("AAAA", "query query query");
        	//UserInfo.mLoginHelper.RegQueryClientSendedMsgStatus(); 
        }    
    }
	
	public void OnError()
	{
		AlertDialog.Builder builder = new Builder(SendMsg.this);
		builder.setMessage("超时，请重发短信");
		builder.setTitle("QQ通行证");
		builder.setPositiveButton("确认", new OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {}
		});
		builder.create().show();		
	}

	WtloginListener mListener = new WtloginListener() {
		@Override
		public void OnRegError(WUserSigInfo userSigInfo, int ret, byte[] msg) {
			util.LOGD("OnRegError:" + ret);
			OnError();
		}

		@Override
		public void OnRegQueryClientSendedMsgStatus(WUserSigInfo userSigInfo, int ret, int next_chk_time,
				int total_time_over) {
			
			if(ret == 0)
			{
				Intent intent = new Intent();
				intent.setClass(SendMsg.this, InputPasswd.class);
				intent.putExtra("TYPE", mRegType);
				intent.putExtra("MSG", mMsg);
				startActivity(intent);
				SendMsg.this.finish();
			}
			else
			{
				if(overTime > total_time_over)
				{
					OnError();
					return;
				}
				refresh  = new CountMsgChk(next_chk_time * 1000, next_chk_time * 1000);
				refresh.start();
			}
			/*if (ret == 0) {
				mMsgEditText.setText("请发短信【"+mMsg+"】至:"+mMobile+",服务器已收到信息");
			} else {
				mMsgEditText.setText("请发短信【"+mMsg+"】至:"+mMobile+",服务器未收到信息");
			}*/
		}

		// url跳转
		public void OnRegCheckValidUrl(WUserSigInfo userSigInfo, byte[] url) {
			util.LOGD("OnRegCheckValidUrl:" + new String(url));
			Intent urlIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(new String(url)));
			startActivity(urlIntent);
			SendMsg.this.finish();
		}

	};

}