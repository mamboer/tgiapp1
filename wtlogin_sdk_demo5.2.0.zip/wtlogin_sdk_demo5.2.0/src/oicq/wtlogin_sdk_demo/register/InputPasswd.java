package oicq.wtlogin_sdk_demo.register;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


import oicq.wlogin_sdk.request.WUserSigInfo;
import oicq.wlogin_sdk.request.WtloginListener;
import oicq.wlogin_sdk.tools.util;
import oicq.wtlogin_sdk_demo.Login;
import oicq.wtlogin_sdk_demo.R;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

@SuppressLint({ "NewApi", "NewApi" })
public class InputPasswd  extends Activity {
	
	int mRegType = 0;
	String mMsg = "";
	
	EditText mPwdEditText;
	Button mNextStepButton;
	private CheckBox showPswd;
	TextView step;
	
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); 
        setContentView(R.layout.inputpswd); 
        
        Intent intent = this.getIntent();
        mRegType = intent.getIntExtra("TYPE", 0);
        mMsg = intent.getStringExtra("MSG");
        
        Login.mLoginHelper.SetListener(mListener);
        step = (TextView)findViewById(R.id.step2);
		step.setTextColor(Color.WHITE);
		TextView title = (TextView)findViewById(R.id.title);
		if(mRegType == 0)
			title.setText(getResources().getString(R.string.regQQ));
		else if(mRegType == 1)
			title.setText(getResources().getString(R.string.regPhone));
		else if(mRegType == 3)
		{
			title.setText(getResources().getString(R.string.regEmail));
			step = (TextView)findViewById(R.id.step1);
			step.setText("①邮箱验证");
		}

        mPwdEditText = (EditText) findViewById(R.id.editText1); 
        mNextStepButton = (Button) findViewById(R.id.btn_next); 
        mNextStepButton.setOnClickListener(new View.OnClickListener() {
        	public void onClick(View v) {
        		int length = mPwdEditText.getText().toString().trim().length();
        		String   regEx  =  "[0-9]*";
        		
        		if(length < 6)
        		{
        			Login.showDialog(InputPasswd.this, "密码不能短于6位。");
					mPwdEditText.setText("");
					return;
        		}
        		else if(length < 9)
        		{
        			Pattern p = Pattern.compile(regEx); 
        		    Matcher m = p.matcher(mPwdEditText.getText().toString().trim()); 
        		    if(m.matches())
        		    {
        		    	Login.showDialog(InputPasswd.this, "密码不能为9位以下纯数字。");
    					mPwdEditText.setText("");
    					return;
        		    }
        		}
        		
        		Pattern pat = Pattern.compile("[\\p{Alnum}\\p{Punct}]*"); //直接用\p{Graph}不行
    		    Matcher mat = pat.matcher(mPwdEditText.getText().toString().trim()); 
    		    if(!mat.matches())
    		    {
    		    	Login.showDialog(InputPasswd.this, "密码不能包含非法符号。");
					mPwdEditText.setText("");
					return;
    		    }
        		
    		    Login.mLoginHelper.RegGetAccount(mMsg.getBytes(), "qqpassport".getBytes(), mPwdEditText
						.getText().toString().getBytes(), new byte[0], mRegType, new WUserSigInfo());
        	} 
        });    
        showPswd = (CheckBox)findViewById(R.id.showPswd);
        showPswd.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				if(!isChecked)
					mPwdEditText.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
				else
					mPwdEditText.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
			}
        	
        });
    }
    
    public boolean isValid(String str)
    {
    	int length = str.length();
    	int  i = 0;
    	boolean ret = true;
    	for(i = 0; i< length; i++)
    	{
    		
    		
    	}
    	return ret;
    }
    
	public void OnError()
	{
		AlertDialog.Builder builder = new Builder(InputPasswd.this);
		builder.setMessage("密码输入有误，请重新输入。");
		builder.setTitle("QQ通行证");
		builder.setPositiveButton("确认", new OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				mPwdEditText.setText("");
			}
		});
		builder.create().show();		
	}
	
    WtloginListener mListener = new WtloginListener(){
    	@Override
    	public void OnRegError(WUserSigInfo userSigInfo, int ret, byte[] msg)
    	{
    		util.LOGI("OnRegError:"+ret);
    		OnError();
    	}
    	
    	@Override
    	public void OnRegGetAccount(WUserSigInfo userSigInfo, int ret, long uin, byte[] supersig, byte[] contactssig, byte[] msg)
    	{
    		util.LOGI("OnRegGetAccount:"+ret+" mRegType="+mRegType);
    		if(ret == 0)
    		{
    			Login.gPasswd = mPwdEditText.getText().toString().trim();
    			if(mRegType == 3)//email
    			{
    				Intent intent = new Intent();
    				intent.setClass(InputPasswd.this, Active.class);
    				intent.putExtra("TYPE", mRegType);
   	    	     	intent.putExtra("UIN", uin);
   	    	     	intent.putExtra("SUPERSIG", mPwdEditText.getText().toString().trim());
    				startActivity(intent);
    				InputPasswd.this.finish();
    				return;
    			}
    			 Intent intent = new Intent();
	       	     intent.setClass(InputPasswd.this, GetUin.class);
	    	     intent.putExtra("TYPE", mRegType);
	    	     intent.putExtra("UIN", uin);
	    	     //intent.putExtra("SUPERSIG", supersig);
	    	     intent.putExtra("SUPERSIG", mPwdEditText.getText().toString().trim());
	    	     startActivity(intent);   
	    	     InputPasswd.this.finish();
    		}
    		else
    		{
    			util.LOGI("OnRegGetAccount error:"+ret);
    			OnError();
    		}
    	}	    	
    	
    };       
       
}
