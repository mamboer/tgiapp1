package oicq.wtlogin_sdk_demo.register;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import oicq.wlogin_sdk.tools.util;
import oicq.wtlogin_sdk_demo.Login;
import oicq.wtlogin_sdk_demo.R;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;


@SuppressLint({ "NewApi", "NewApi" })
public class Active extends Activity {
	private TextView step;
	private Button toActive;
	private TextView toLogin;
	private int mRegType;
	private long mUin;
	private boolean actived = false;
	
	public void onCreate(Bundle savedInstanceState) {
		try{
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); 
        setContentView(R.layout.active); 
        
        step = (TextView)findViewById(R.id.step3);
        step.setTextColor(Color.WHITE);
        step = (TextView)findViewById(R.id.step1);
		step.setText("①邮箱验证");
        
        //Intent intent = this.getIntent();
		//mRegType = intent.getIntExtra("TYPE", 0);
		//mUin = intent.getLongExtra("UIN", 0);
        
        toActive = (Button)findViewById(R.id.btn_active);
        toActive.setOnClickListener(onClick);
        toLogin = (TextView)findViewById(R.id.btn_login);
        toLogin.setOnClickListener(onClick);
		}catch(Exception e)
		{
			util.LOGD(e.toString());
		}
	}
	
	protected void onResume() {
		super.onResume();
		
		Uri data = getIntent().getData();
		if(data == null)
		{
			return;
		}
		
			Log.e("AAAA", "return&data:" + data.toString());
			LinearLayout before = (LinearLayout)findViewById(R.id.beforeActive);
			before.setVisibility(View.GONE);
			LinearLayout after = (LinearLayout)findViewById(R.id.afterActive);
			after.setVisibility(View.VISIBLE);
			Button btn = (Button)findViewById(R.id.btn_active);
			btn.setVisibility(View.GONE);
			btn = (Button)findViewById(R.id.btn_login);
			btn.setVisibility(View.VISIBLE);
			TextView account = (TextView)findViewById(R.id.bduin);
			account.setText("12345567");
			TextView eMail = (TextView)findViewById(R.id.emailAccount);
			eMail.setText(Login.gAccount);
	}
	
	private View.OnClickListener onClick = new View.OnClickListener()
	{
		public void onClick(View arg0) {
			switch(arg0.getId())
			{
				case R.id.btn_active:
					{
						//String key = "R.string." + InputEmail.mEmailDomain.toLowerCase();
						//String strUrl = getString(R.string.sugTitle); 
						actived = true;
						Resources res=getResources();
						int id = res.getIdentifier(InputEmail.mEmailDomain.toLowerCase(),"string",getPackageName());
						//Log.e("AAAA", "the url:"+getString(id));
						String url = "about:blank";
						if(id != 0)
							url = getString(id);
						Intent intent = new Intent("android.intent.action.VIEW",Uri.parse(url));
						startActivity(intent);
						Active.this.finish();
					}
					break;
				case R.id.btn_login://激活完成以后跳到登录页还是注册完成页保存QQ号？
					{
						Intent intent = new Intent();
						intent.setClass(Active.this, Login.class);
						startActivity(intent);
						Active.this.finish();
					}
					break;
				default:
					break;
			}
		}	
	};
	
	public void onWindowFocusChanged(boolean hasFocus) {
        // TODO Auto-generated method stub
        super.onWindowFocusChanged(hasFocus);
        //saveUin();
    }
	
	public void saveUin()
	{
		View view = Active.this.getWindow().getDecorView();
	    view.setDrawingCacheEnabled(true);
	    view.buildDrawingCache();
	    Bitmap b1 = view.getDrawingCache();

	    Rect frame = new Rect();
	    DisplayMetrics metric = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metric);

	    // 获取屏幕长和高
	    int width = metric.widthPixels;
	    int height = metric.heightPixels;
	    
        getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
        int statusBarHeight = frame.top;

	    Bitmap bmp = Bitmap.createBitmap(b1, 0, statusBarHeight, width, height- statusBarHeight);
	    view.destroyDrawingCache();
	    
	    String path = Environment.getExternalStorageDirectory() + "/Pictures";
	    File file = new File(path);
	    if(!file.exists())
	    	file.mkdir();
	    
	    file = new File(path + "/" + mUin + ".jpg");

         FileOutputStream f = null;
         try {
        	 f = new FileOutputStream(file);
        	 boolean b = bmp.compress(Bitmap.CompressFormat.JPEG, 100, f);
             if(b){
            	 f.flush();
             }
             f.close();
         } catch (FileNotFoundException e) {
        	 e.printStackTrace();
         }
         catch (IOException e) {
             e.printStackTrace();
         }
         
	}
}
