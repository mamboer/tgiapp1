package oicq.wtlogin_sdk_demo.register;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import oicq.wlogin_sdk.tools.util;
import oicq.wtlogin_sdk_demo.Login;
import oicq.wtlogin_sdk_demo.R;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

@SuppressLint("NewApi")
public class GetUin extends Activity {
	int mRegType = 0;
	long mUin;
	//byte[] mSuperSig = new byte[0];
	private String mSuperSig = "";

	Button mNextStepButton;
	TextView mMsgEditText;
	TextView step;
	TextView bduin;
	TextView bd;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		//setContentView(R.layout.getuin);
		setContentView(R.layout.regok);
		
		Intent intent = this.getIntent();
		mRegType = intent.getIntExtra("TYPE", 0);
		mUin = intent.getLongExtra("UIN", 0);
		
		//mSuperSig = intent.getByteArrayExtra("SUPERSIG");
		
		step = (TextView)findViewById(R.id.step3);
		step.setTextColor(Color.WHITE);
		//step.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, R.drawable.nowstep);
		
		TextView title = (TextView)findViewById(R.id.title);
		if(mRegType == 0)
			title.setText(getResources().getString(R.string.regQQ));
		else if(mRegType == 1)
			title.setText(getResources().getString(R.string.regPhone));

		mMsgEditText = (TextView) findViewById(R.id.account);
		if(mRegType == 0)
		{
			Login.gAccount = Long.toString(mUin);
			mMsgEditText.setText(Login.gAccount);
			
		}
		else if(mRegType == 1)
		{
			mMsgEditText.setText(Login.gAccount);
			mMsgEditText.getPaint().setTypeface(Typeface.SERIF);
			bd = (TextView)findViewById(R.id.bd);
			bd.setVisibility(View.VISIBLE);
			bduin = (TextView)findViewById(R.id.bduin);
			bduin.setVisibility(View.VISIBLE);
			bduin.setText(Long.toString(mUin));
		}

		mNextStepButton = (Button) findViewById(R.id.btn_login);
		mNextStepButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Login.gLoginNow = true;
				finish();
			}
		});
		
	}
	
	public void onWindowFocusChanged(boolean hasFocus) {
        // TODO Auto-generated method stub
        super.onWindowFocusChanged(hasFocus);
        saveUin();
    }
	
	public void saveUin()
	{
		View view = GetUin.this.getWindow().getDecorView();
	    view.setDrawingCacheEnabled(true);
	    view.buildDrawingCache();
	    Bitmap b1 = view.getDrawingCache();

	    Rect frame = new Rect();
	    DisplayMetrics metric = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metric);

	    // 获取屏幕长和高
	    int width = metric.widthPixels;
	    int height = metric.heightPixels;
	    
	    
        getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
        int statusBarHeight = frame.top;

	    Bitmap bmp = Bitmap.createBitmap(b1, 0, statusBarHeight, width, height- statusBarHeight);
	    view.destroyDrawingCache();
	    
	    String path = Environment.getExternalStorageDirectory() + "/wlogin_sdk_demo/";
	    File file = new File(path);
	    if(!file.exists())
	    	file.mkdir();
	    
	    File myPic = new File(path + mUin + ".jpg");

         FileOutputStream f = null;
         try {
        	 f = new FileOutputStream(myPic);
        	 boolean b = bmp.compress(Bitmap.CompressFormat.JPEG, 100, f);
             if(b){
            	 f.flush();
             }
             f.close();
         } catch (FileNotFoundException e) {
        	 e.printStackTrace();
         }
         catch (IOException e) {
             e.printStackTrace();
         }
         
         sendBroadcast(new Intent(Intent.ACTION_MEDIA_MOUNTED, Uri.parse("file://"  
                 + Environment.getExternalStorageDirectory() + "/wlogin_sdk_demo")));
         //sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,Uri.parse("file://"+Environment.getExternalStorageDirectory()+"//dir")));

	}

}
