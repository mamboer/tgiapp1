package oicq.wtlogin_sdk_demo.register;

import oicq.wlogin_sdk.request.WUserSigInfo;
import oicq.wlogin_sdk.request.WtloginListener;
import oicq.wlogin_sdk.tools.util;
import oicq.wtlogin_sdk_demo.Login;
import oicq.wtlogin_sdk_demo.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class InputEmail extends Activity {

	int mRegType = 0;
	int mFlowId = 0;
	Button mNextStepButton;
	EditText mEmail;
	CheckBox agree;
	TextView serverItem;
	TextView step;
	
	public static String mEmailDomain="";  

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE); 
		setContentView(R.layout.inputemail);

		Intent intent = getIntent();
		mRegType = intent.getIntExtra("TYPE", 0);
		util.LOGD("InputEmail::onCreate:" + mRegType);

		Login.mLoginHelper.SetListener(mListener);
		step = (TextView)findViewById(R.id.step1);
		step.setText("①邮箱验证");
		step.setTextColor(Color.WHITE);
		ImageView step3 = (ImageView)findViewById(R.id.step);
		step3.getBackground().setAlpha(150);

		agree = (CheckBox)findViewById(R.id.checkOK);
		serverItem = (TextView)findViewById(R.id.agree);
		serverItem.setOnClickListener(onClick);
		serverItem.setOnTouchListener(onTouchListener);
		
		mEmail = (EditText) findViewById(R.id.editText1);
		mNextStepButton = (Button) findViewById(R.id.btn_next);
		mNextStepButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				mEmailDomain = mEmail.getText().toString().trim();
				if(mEmailDomain.length() == 0)
				{
					Login.showDialog(InputEmail.this, "请输入邮箱帐号。");
					return;
				}
				if(!agree.isChecked())
				{
					Login.showDialog(InputEmail.this, "对不起，您还未同意《腾讯QQ服务条款》。"); 
					return;
				}
				
				int pos = mEmailDomain.indexOf("@");
				if(-1 == pos){
					OnError();
					return;
				}else{
					
					mEmailDomain = mEmailDomain.substring(pos+1);
					if(mEmailDomain.length() > 0 && (mEmailDomain.charAt(0)>='0' && mEmailDomain.charAt(0)<='9'))
						mEmailDomain = "N"+mEmailDomain;
					util.LOGD(mEmailDomain);
				}
				Login.mLoginHelper.RegQueryAccount(mRegType, mEmail
						.getText().toString().getBytes(),
						Login.mAppid, null);
			}
		});
	}
	
	private View.OnTouchListener onTouchListener = new View.OnTouchListener() {
		public boolean onTouch(View v, MotionEvent event) {
			int id = v.getId();
	        switch(event.getAction())
	        {
	        	case MotionEvent.ACTION_DOWN:
	        		{
	        			if(id == R.id.agree)
	        				serverItem.setTextColor(InputEmail.this.getResources().getColor(R.color.textFocus));
	        		}
	        		break;
	        	case MotionEvent.ACTION_UP:
	        		{
	        			if(id == R.id.agree)
	        				serverItem.setTextColor(InputEmail.this.getResources().getColor(R.color.white));
	        		}
	        		break;
	        	case MotionEvent.ACTION_MOVE:
	        		break;
	        }
			return false;
		}
	};
	
	private View.OnClickListener onClick = new View.OnClickListener()
	{
		public void onClick(View v) {
			switch(v.getId())
			{
				case R.id.agree:
					{
						Intent intent = new Intent("android.intent.action.VIEW",Uri.parse(getString(R.string.agreeItem)));
						startActivity(intent);
					}
					break;
				default:
					break;
			}
		}
	};

	public void OnError() {
		AlertDialog.Builder builder = new Builder(InputEmail.this);
		builder.setMessage("对不起，您输入的电子邮箱无效。");
		builder.setTitle("QQ通行证");
		builder.setPositiveButton("确认", new OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				mEmail.setText("");
			}
		});
		builder.create().show();
	}
	
	public void OnExist() {
		AlertDialog.Builder builder = new Builder(InputEmail.this);
		builder.setMessage("邮箱帐号已存在");
		builder.setTitle("QQ通行证");
		builder.setPositiveButton("确认", new OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
			}
		});
		builder.create().show();
	}	

	WtloginListener mListener = new WtloginListener() {
		@Override
		public void OnRegError(WUserSigInfo userSigInfo, int ret, byte[] msg) {
			util.LOGD("OnRegError:" + ret + ", msg: " + msg);
			OnError();
		}

		/*
		 * 
		 * //CResultCode ： 0 辅助账号不存在，后续注册需要验证手机号， 1 辅助账号已存在，后续注册需要验证手机 
		 * 2 辅助账号不存在，后续注册不需要验证手机号 3辅助账号存在，后续注册不验证手机
		 */
		@Override
		public void OnRegQueryAccount(WUserSigInfo userSigInfo, int ret, byte[] msg) {
			util.LOGD("OnRegQueryAccount:" + ret);
			mFlowId = ret;

			switch (mFlowId) {
			case 0:
				{
					Login.gAccount = mEmail.getText().toString().trim();
					Intent intent = new Intent();
					intent.setClass(InputEmail.this, InputMobile.class);
					intent.putExtra("TYPE", mRegType);
					intent.putExtra("MSG", new String(msg));
					startActivity(intent);
					InputEmail.this.finish();
				}
				break;
			case 2:
				{
					Login.gAccount = mEmail.getText().toString().trim();
					Intent intent = new Intent();
					intent.setClass(InputEmail.this, InputPasswd.class);
					intent.putExtra("TYPE", mRegType);
					intent.putExtra("MSG", new String(msg));
					//intent.putExtra("ACCOUNT", mEmail.getText().toString().trim());
					startActivity(intent);
					InputEmail.this.finish();
				}
				break;
			case 1:
			case 3:
			{
				OnExist();
			}
				break;
			default:
				OnError();
				break;
			}
		}

	};

}