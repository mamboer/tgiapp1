/** Automatically generated file. DO NOT MODIFY */
package oicq.wtlogin_sdk_demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}